public class StringDemo07{
	public static void main(String args[]){
		String str1 = "hello" ;					// ֱ�Ӹ�ֵ
		String str2 = "hello" ;					// ֱ�Ӹ�ֵ
		String str3 = "hello" ;					// ֱ�Ӹ�ֵ
		System.out.println("str1 == str2 --> " + (str1==str2)) ;	// true
		System.out.println("str1 == str3 --> " + (str1==str3)) ;	// true
		System.out.println("str2 == str3 --> " + (str2==str3)) ;	// true
	}
};