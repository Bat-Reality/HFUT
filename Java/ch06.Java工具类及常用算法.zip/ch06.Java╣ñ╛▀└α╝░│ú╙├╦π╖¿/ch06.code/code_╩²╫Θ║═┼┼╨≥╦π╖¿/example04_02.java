//ArrayCopy
//��ά����ĸ���

public class example04_02{
  public static void main(String args[]){
    int c[][],d[][],i,j;
    c=new int[2][2];
    d=new int[3][3];
    System.out.println("  Array d");
    for (i=0;i<d.length;i++){
      for (j=0;j<d[i].length;j++){
      	d[i][j]=i+j;
        System.out.print( d[i][j]+"  "); 
      }
      System.out.println();
    }
    c=d;
    System.out.println("  Array c");
    for (i=0;i<c.length;i++){
      for(j=0;j<c[i].length;j++)
        System.out.print( c[i][j]+"  ");
      System.out.println( );
    }
  }
} 