public interface Fruit {
	//�ɼ�
	public void get();
}