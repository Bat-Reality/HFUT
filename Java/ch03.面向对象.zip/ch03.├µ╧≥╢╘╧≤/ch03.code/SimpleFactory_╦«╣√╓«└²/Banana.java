public class Banana implements Fruit{
  //�ɼ�
  public void get(){
    System.out.println("�ɼ��㽶");
	}
}