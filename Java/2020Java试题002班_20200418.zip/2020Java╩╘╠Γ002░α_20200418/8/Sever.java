import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Sever {
	public static void main(String[] args) throws IOException {
		ServerSocket serverSocket = new ServerSocket(8686);
		Socket socket = serverSocket.accept();
		InputStream inputStream = socket.getInputStream();
		OutputStream outputStream = socket.getOutputStream();
		InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		
		OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
		BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
		System.out.println("客户端连接，服务开始");
		while(true)
		{
			int a = Integer.parseInt(bufferedReader.readLine());
			int b = Integer.parseInt(bufferedReader.readLine());
			int c = a+b;
			bufferedWriter.write(""+c);
			bufferedWriter.newLine();
			bufferedWriter.flush();
			
			if (c == 100) {
				
				break;
			}
		}
		System.out.println("程序结束！");
		bufferedReader.close();
		bufferedWriter.close();
		socket.close();
	}
}
