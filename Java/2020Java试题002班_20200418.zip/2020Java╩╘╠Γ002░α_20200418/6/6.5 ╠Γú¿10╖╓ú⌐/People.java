
public class People {
	private int age;
	private String name;
	public People(int age,String name) {
		// TODO Auto-generated constructor stub
		this.setAge(age);
		this.setName(name);
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
