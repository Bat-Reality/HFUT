public class Student extends People {
	private String school = "HFUT";
	public void showName() {
		System.out.println("Myname:"+name);
	}
	public static void showSchool() {
		System.out.println("MySchool:"+school);
	}
 public static void main(String[] args) {
	Student student = new Student();
	student.showName();
 	}
} 