public class Test4 {
 public static void main(String[] args) {
	 my_method();

	 public static void my_method() {
		 Scanner scanner = new Scanner(System.in);
		 int a = scanner.nextDouble();
		 System.out.println("the float numer you enter is"+a);
	 }
} 