public class Demo {
	public static void main(String[] args) {
		int a = 3;
		int b = 4;
		int c = 20;
 
		average = (a + b + c)/5.0;
		System.out.println(average);
	}
}