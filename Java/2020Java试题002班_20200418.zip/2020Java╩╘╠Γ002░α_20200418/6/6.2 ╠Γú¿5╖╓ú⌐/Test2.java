public class Test2 {
	 public void main(String[] args) {
		 my_method;
	 }
 
	 public static void my_method() {
		 System.out.println("Hello, world!");
	 }
}
